CASH SPORTS — Free Fire Top-Up Website (Front-end Demo)

ফাইল:
- index.html : সম্পূর্ণ responsive demo website

চালানোর নিয়ম:
1. ZIP ফাইলটি extract করুন।
2. index.html ফাইলে চাপ দিন বা browser-এ খুলুন।
3. প্যাকেজের দাম packages array-তে পরিবর্তন করুন।
4. paymentHint-এর নমুনা লেখা বদলে আপনার বৈধ পেমেন্ট নম্বর বসান।

গুরুত্বপূর্ণ সীমাবদ্ধতা:
- এটি শুধু front-end demo; অর্ডার কেবল একই ব্রাউজারের localStorage-এ থাকে।
- বাস্তব ক্রেতার অর্ডার আপনার কাছে আসবে না।
- Admin panel নিরাপদ নয়; login বা server-side access control নেই।
- TrxID এখানে যাচাই হয় না এবং কোনো টাকা নেওয়া হয় না।
- পাবলিকভাবে চালুর আগে backend/database (যেমন Supabase/Firebase), secure admin authentication, server-side validation, privacy notice এবং hosting setup দরকার।
- Free Fire-এর অফিসিয়াল অনুমোদন/নীতিমালা এবং payment provider-এর শর্ত যাচাই করুন।

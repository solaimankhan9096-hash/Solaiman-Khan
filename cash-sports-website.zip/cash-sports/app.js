import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore, collection, addDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { firebaseConfig, paymentNumbers, packages } from "./firebase-config.js";

const $ = (id) => document.getElementById(id);
$("year").textContent = new Date().getFullYear();
const configReady = firebaseConfig.apiKey !== "YOUR_API_KEY" && firebaseConfig.projectId !== "YOUR_PROJECT_ID";
let db = null;
try { if (configReady) db = getFirestore(initializeApp(firebaseConfig)); } catch (e) { console.error(e); }

function showMessage(el, msg, error=false) { el.textContent = msg; el.style.color = error ? "#ff9999" : "#55d6a2"; }
function renderPackages() {
  $("packages").innerHTML = "";
  $("package").innerHTML = '<option value="">প্যাকেজ বেছে নিন</option>';
  packages.forEach(p => {
    const card = document.createElement("article"); card.className = "package";
    const icon = document.createElement("div"); icon.className="diamond"; icon.textContent="💎";
    const title = document.createElement("h3"); title.textContent=p.name;
    const desc = document.createElement("p"); desc.textContent=`${p.diamonds} Diamonds`;
    const price = document.createElement("div"); price.className="price"; price.textContent=`৳${p.price}`;
    const btn = document.createElement("button"); btn.className="btn"; btn.textContent="এই প্যাকেজ নিন";
    btn.addEventListener("click", () => { $("package").value=p.id; $("order-section").scrollIntoView({behavior:"smooth"}); });
    card.append(icon,title,desc,price,btn); $("packages").append(card);
    const opt=document.createElement("option"); opt.value=p.id; opt.textContent=`${p.name} — ৳${p.price}`; $("package").append(opt);
  });
}
renderPackages();
$("payment").addEventListener("change", () => {
  const method=$("payment").value;
  $("payment-instructions").textContent = method ? `${method} নম্বর: ${paymentNumbers[method] || "অ্যাডমিনের সঙ্গে যোগাযোগ করুন"} — সঠিক নম্বর নিশ্চিত করে পেমেন্ট করুন।` : "পেমেন্ট মাধ্যম বেছে নিলে নির্দেশনা দেখানো হবে।";
});
$("order-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const msg=$("form-message"), button=$("submit-order");
  if (!db) return showMessage(msg,"Firebase config যোগ করা হয়নি। README-র সেটআপ ধাপ অনুসরণ করুন।",true);
  const p=packages.find(x=>x.id===$("package").value);
  if(!p) return showMessage(msg,"একটি প্যাকেজ বেছে নিন।",true);
  const playerId=$("playerId").value.trim(), contact=$("contact").value.trim();
  const payment=$("payment").value, sender=$("sender").value.trim(), trx=$("trx").value.trim();
  if(!/^\d{5,20}$/.test(playerId)) return showMessage(msg,"Player ID ৫–২০ সংখ্যার হতে হবে।",true);
  if(!payment || sender.length<5 || trx.length<4) return showMessage(msg,"পেমেন্টের তথ্য যাচাই করুন।",true);
  button.disabled=true; button.textContent="জমা হচ্ছে…";
  try {
    const orderRef=await addDoc(collection(db,"orders"),{
      orderCode:"CS-"+Date.now().toString(36).toUpperCase()+"-"+Math.random().toString(36).slice(2,6).toUpperCase(),
      packageId:p.id, packageName:p.name, diamonds:p.diamonds, price:p.price,
      playerId, contact, paymentMethod:payment, senderNumber:sender, transactionId:trx,
      status:"pending", createdAt:serverTimestamp()
    });
    const snap=await getDocs(query(collection(db,"orders"),where("orderCode","==",(await import("firebase/firestore")).doc ? "" : ""))).catch(()=>null);
    // অর্ডার কোডটি Firestore document ID-র বদলে আলাদা কোড; এটি শুধু সফল সাবমিশনের নিশ্চিতকরণে দেখান।
    showMessage(msg,`অর্ডার জমা হয়েছে! আপনার অর্ডার নম্বর: ${orderRef.id}। এই নম্বরটি সংরক্ষণ করুন।`);
    $("order-code").value=orderRef.id;
    $("order-form").reset(); $("payment-instructions").textContent="পেমেন্ট মাধ্যম বেছে নিলে নির্দেশনা দেখানো হবে।";
  } catch(err) {
    console.error(err); showMessage(msg,"অর্ডার জমা হয়নি। ইন্টারনেট ও Firebase Rules পরীক্ষা করুন।",true);
  } finally { button.disabled=false; button.textContent="অর্ডার জমা দিন"; }
});
function statusBn(s){return ({pending:"পেমেন্ট যাচাই বাকি",verified:"পেমেন্ট যাচাই হয়েছে",processing:"প্রসেসিং চলছে",completed:"সম্পন্ন",rejected:"বাতিল"})[s]||"পেন্ডিং";}

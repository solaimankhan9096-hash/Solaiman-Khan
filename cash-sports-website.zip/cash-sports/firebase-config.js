// Firebase Console > Project settings > Your apps > SDK setup.
// নিচের মানগুলো নিজের Firebase Web App config দিয়ে প্রতিস্থাপন করুন।
export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  appId: "YOUR_APP_ID"
};

// নিজের সক্রিয় মার্চেন্ট/পার্সোনাল নম্বর বসান। বাস্তবে পেমেন্ট নেওয়ার আগে
// সংশ্লিষ্ট সেবার শর্ত ও ব্যবসায়িক ব্যবহার-অনুমতি যাচাই করুন।
export const paymentNumbers = {
  bKash: "আপনার bKash নম্বর",
  Nagad: "আপনার Nagad নম্বর",
  Rocket: "আপনার Rocket নম্বর"
};

// নমুনা প্যাকেজ ও মূল্য—প্রকাশের আগে নিজের প্রকৃত অফার/মূল্য ঠিক করুন।
export const packages = [
  { id: "p1", name: "25 Diamonds", diamonds: 25, price: 25 },
  { id: "p2", name: "50 Diamonds", diamonds: 50, price: 40 },
  { id: "p3", name: "115 Diamonds", diamonds: 115, price: 80 },
  { id: "p4", name: "240 Diamonds", diamonds: 240, price: 160 },
  { id: "p5", name: "610 Diamonds", diamonds: 610, price: 390 },
  { id: "p6", name: "1240 Diamonds", diamonds: 1240, price: 780 }
];
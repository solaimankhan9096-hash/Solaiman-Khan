# Cash Sports — Free Fire Top-Up

বাংলা স্টোরফ্রন্ট, Firebase Authentication অ্যাডমিন লগইন এবং Firestore অর্ডার স্টোরেজ। GitHub Pages-এ হোস্ট করা যায়।

## 1) Firebase তৈরি
1. https://console.firebase.google.com/ খুলে নতুন project তৈরি করুন।
2. Project settings → General → Your apps → Web app তৈরি করুন।
3. SDK config থেকে `apiKey`, `authDomain`, `projectId`, `appId` কপি করে `firebase-config.js`-এ বসান।
4. Build → Authentication → Sign-in method থেকে **Email/Password** চালু করুন।
5. Authentication → Users থেকে নিজের অ্যাডমিন ইমেইল/পাসওয়ার্ড দিয়ে ব্যবহারকারী তৈরি করুন।
6. Build → Firestore Database → Create database করুন।
7. `firestore.rules`-এ `REPLACE_WITH_ADMIN_EMAIL`-এর জায়গায় অ্যাডমিনের ইমেইল বসিয়ে Rules publish করুন। একই ইমেইল Firebase Auth user-এর সঙ্গে মিলতে হবে।
8. `firebase-config.js`-এর `paymentNumbers`-এ নিজের সঠিক পেমেন্ট নম্বর বসান।
9. `packages` তালিকার নমুনা প্যাকেজ/মূল্য যাচাই করে নিজের মূল্য নির্ধারণ করুন।

## 2) GitHub Pages-এ প্রকাশ
1. GitHub-এ নতুন **Public** repository তৈরি করুন, যেমন `cash-sports`.
2. এই ZIP extract করে সব ফাইল repository-র root-এ upload করুন: `index.html`, `admin.html`, `app.js`, `admin.js`, `style.css`, `firebase-config.js`, `firestore.rules`, `README.md`.
3. Repository → Settings → Pages → Build and deployment → Deploy from a branch নির্বাচন করুন।
4. Branch `main`, folder `/ (root)` নির্বাচন করে Save করুন।
5. প্রকাশিত URL হবে `https://YOUR-USERNAME.github.io/cash-sports/` (GitHub দেখানো URL-ই ব্যবহার করুন)।
6. Firebase Authentication → Settings → Authorized domains-এ `YOUR-USERNAME.github.io` যোগ করুন। প্রয়োজনে Firebase console-এর বর্তমান নির্দেশনা অনুসরণ করুন।

## 3) কীভাবে ব্যবহার করবেন
- গ্রাহক: হোমপেজ → প্যাকেজ → Player ID → পেমেন্ট মাধ্যম → sender number ও Transaction ID → অর্ডার জমা।
- অ্যাডমিন: `/admin.html` → Firebase Auth লগইন → Transaction ID পেমেন্ট অ্যাপ/স্টেটমেন্টে যাচাই → স্ট্যাটাস বদলান।
- অর্ডার নম্বরটি Firestore document ID। গ্রাহককে সেটি সংরক্ষণ করতে বলুন।

## 4) গুরুত্বপূর্ণ সীমাবদ্ধতা ও নিরাপত্তা
- এই প্রকল্প ম্যানুয়াল পেমেন্ট যাচাইয়ের জন্য। Transaction ID দেওয়া মানেই টাকা পাওয়া প্রমাণ নয়।
- নমুনা Diamond পরিমাণ/দাম শুধু placeholder; প্রকাশের আগে বাস্তব প্যাকেজ ও মূল্য যাচাই করুন।
- Firebase web config সাধারণত client-এ থাকে; নিরাপত্তা Firestore Rules এবং Authentication-এর ওপর নির্ভর করে।
- অ্যাডমিন ইমেইলটি Rules-এ নির্দিষ্ট করুন। অন্য কাউকে admin account দেবেন না; শক্তিশালী পাসওয়ার্ড ও 2FA ব্যবহার করুন যদি উপলভ্য থাকে।
- বর্তমান Rules অনুযায়ী গ্রাহক নিজের অর্ডারের অবস্থা public lookup-এ দেখতে পারবে না; নিরাপত্তার জন্য সেই সুবিধা বন্ধ রাখা হয়েছে। Admin panel থেকে অর্ডার স্ট্যাটাস দেখা যায়। Customer status lookup যোগ করতে হলে Cloud Function/secure token-based endpoint ব্যবহার করুন, সব অর্ডার public read খুলবেন না।
- এই front-end demo-তে App Check, rate limiting, duplicate Transaction ID detection, refund workflow, audit log, automated top-up API বা delivery integration নেই। বাস্তব ব্যবসায় ব্যবহারের আগে এগুলো যোগ করুন।
- Firebase-এর বর্তমান কনসোল UI/ফ্রি কোটা পরিবর্তিত হতে পারে; প্রকাশের আগে official docs যাচাই করুন।
- Cash Sports স্বাধীন স্টোর; Garena/Free Fire-এর সঙ্গে অনুমোদিত সম্পর্ক বোঝায় না। গেমের নাম/লোগোর ব্যবহারসংক্রান্ত নীতি ও অনুমতি যাচাই করুন।

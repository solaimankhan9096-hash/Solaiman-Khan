import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, signOut } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { getFirestore, collection, getDocs, doc, updateDoc, query, orderBy, limit } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";
const $=id=>document.getElementById(id);
const ready=firebaseConfig.apiKey!=="YOUR_API_KEY"&&firebaseConfig.projectId!=="YOUR_PROJECT_ID";
let auth,db;
if(ready){const app=initializeApp(firebaseConfig);auth=getAuth(app);db=getFirestore(app);}
function msg(el,t,error=false){el.textContent=t;el.style.color=error?"#ff9999":"#55d6a2";}
$("login-form").addEventListener("submit",async e=>{e.preventDefault();if(!ready)return msg($("login-message"),"আগে firebase-config.js-এ Firebase config বসান।",true);try{await signInWithEmailAndPassword(auth,$("email").value.trim(),$("password").value);}catch(err){msg($("login-message"),"লগইন ব্যর্থ। ইমেইল/পাসওয়ার্ড ও Firebase Auth সেটিংস যাচাই করুন।",true);}});
$("logout").addEventListener("click",()=>signOut(auth));
$("refresh").addEventListener("click",loadOrders);
if (ready) {
 onAuthStateChanged(auth,user=>{ $("login-panel").classList.toggle("hidden",!!user);$("dashboard").classList.toggle("hidden",!user);if(user)loadOrders();});
} else {
 msg($("login-message"),"Firebase config যোগ করতে README.md অনুসরণ করুন।",true);
}
const statuses=[["pending","পেমেন্ট যাচাই বাকি"],["verified","পেমেন্ট যাচাই হয়েছে"],["processing","প্রসেসিং চলছে"],["completed","সম্পন্ন"],["rejected","বাতিল"]];
async function loadOrders(){
 if(!auth?.currentUser)return;
 const body=$("orders-body");body.replaceChildren();msg($("admin-message"),"অর্ডার লোড হচ্ছে…");
 try{
  const q=query(collection(db,"orders"),orderBy("createdAt","desc"),limit(100));const snap=await getDocs(q);
  if(snap.empty){msg($("admin-message"),"এখনও কোনো অর্ডার নেই।");return;}
  snap.forEach(s=>{
   const d=s.data(),tr=document.createElement("tr");
   const values=[s.id,d.packageName||"",d.playerId||"",`${d.paymentMethod||""} / ${d.senderNumber||""}`,d.transactionId||""];
   values.forEach(v=>{const td=document.createElement("td");td.textContent=String(v);tr.append(td);});
   const statusTd=document.createElement("td"),select=document.createElement("select");
   statuses.forEach(([value,label])=>{const op=document.createElement("option");op.value=value;op.textContent=label;select.append(op);});
   select.value=statuses.some(x=>x[0]===d.status)?d.status:"pending";statusTd.append(select);tr.append(statusTd);
   const actionTd=document.createElement("td"),save=document.createElement("button");save.className="small-btn";save.textContent="সংরক্ষণ";
   save.addEventListener("click",async()=>{save.disabled=true;try{await updateDoc(doc(db,"orders",s.id),{status:select.value,updatedAt:new Date().toISOString()});msg($("admin-message"),"স্ট্যাটাস আপডেট হয়েছে।");}catch(e){msg($("admin-message"),"আপডেট ব্যর্থ—Rules যাচাই করুন।",true);}finally{save.disabled=false;}});
   actionTd.append(save);tr.append(actionTd);body.append(tr);
  });
  msg($("admin-message"),`${snap.size}টি সাম্প্রতিক অর্ডার দেখানো হচ্ছে।`);
 }catch(e){console.error(e);msg($("admin-message"),"অর্ডার লোড হয়নি। Firestore Rules ও index/config পরীক্ষা করুন।",true);}
}
